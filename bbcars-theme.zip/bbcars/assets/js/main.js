(function(){
  var grid=document.getElementById('apGrid');
  if(grid){var cards=[].slice.call(grid.children), filt='all', q='';
  function apply(){
    var n=0;
    cards.forEach(function(c){
      var ok=(filt==='all'||(filt==='ev'&&c.dataset.ev==='1')||(filt==='al'&&c.dataset.al==='1')||c.dataset.g===filt)&&(!q||c.dataset.name.indexOf(q)>-1);
      c.hidden=!ok; if(ok)n++;});
    document.getElementById('apCount').textContent='Showing '+n+' of '+cards.length+' approvals';
    document.getElementById('apEmpty').hidden=n>0;
  }
  document.getElementById('apSearch').addEventListener('input',function(e){q=e.target.value.trim().toLowerCase();apply()});
  [].forEach.call(document.querySelectorAll('.chip'),function(b){b.addEventListener('click',function(){filt=b.dataset.f;[].forEach.call(document.querySelectorAll('.chip'),function(x){x.setAttribute('aria-pressed',x===b)});apply()})});
  apply();
  }

  // Drawer
  var dr=document.getElementById('drawer'), mb=document.getElementById('menuBtn');
  function setDr(o){dr.classList.toggle('open',o);dr.setAttribute('aria-hidden',!o);mb.setAttribute('aria-expanded',o);document.body.style.overflow=o?'hidden':''}
  mb.addEventListener('click',function(){setDr(true)});
  document.getElementById('menuClose').addEventListener('click',function(){setDr(false)});
  [].forEach.call(dr.querySelectorAll('a'),function(a){a.addEventListener('click',function(){setDr(false)})});

  // Hero slider
  var hero=document.getElementById('hero');
  if(hero){var slides=hero.querySelectorAll('.slide'), dots=hero.querySelectorAll('.dot'), cur=0, timer, DUR=4500;
  var reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  hero.style.setProperty('--dur',DUR+'ms');
  function go(i){
    slides[cur].classList.remove('on');slides[cur].setAttribute('aria-hidden','true');dots[cur].classList.remove('on');dots[cur].setAttribute('aria-selected','false');
    cur=(i+slides.length)%slides.length;
    slides[cur].classList.add('on');slides[cur].removeAttribute('aria-hidden');dots[cur].classList.add('on');dots[cur].setAttribute('aria-selected','true');
    var b=dots[cur].querySelector('.bar i'); b.style.animation='none'; void b.offsetWidth; b.style.animation='';
    restart();
  }
  function restart(){clearTimeout(timer); if(!hero.classList.contains('paused')) timer=setTimeout(function(){go(cur+1)},DUR)}
  slides[0].classList.add('on');
  [].forEach.call(dots,function(d,i){d.addEventListener('click',function(){go(i)})});
  document.getElementById('prev').addEventListener('click',function(){go(cur-1)});
  document.getElementById('next').addEventListener('click',function(){go(cur+1)});
  hero.addEventListener('keydown',function(e){if(e.key==='ArrowLeft')go(cur-1);if(e.key==='ArrowRight')go(cur+1)});
  var sx=null;
  hero.addEventListener('touchstart',function(e){sx=e.touches[0].clientX},{passive:true});
  hero.addEventListener('touchend',function(e){if(sx===null)return;var dx=e.changedTouches[0].clientX-sx;if(Math.abs(dx)>45)go(cur+(dx<0?1:-1));sx=null},{passive:true});
  if(reduce){hero.classList.add('paused')}
  restart();}

  // Active nav
  var links=document.querySelectorAll('.nav a'), secs=[].map.call(links,function(a){var h=a.getAttribute('href')||'',i=h.indexOf('#');if(i<0||!document.body.classList.contains('home'))return null;try{return document.querySelector(h.slice(i))}catch(e){return null}});
  if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){var i=secs.indexOf(e.target);[].forEach.call(links,function(l,j){l.classList.toggle('active',i===j)})}})},{rootMargin:'-45% 0px -50% 0px'});secs.forEach(function(s){s&&io.observe(s)})}

  // Repair steps: fade in one at a time when they scroll into view
  var steps=document.querySelector('.steps');
  if(steps&&'IntersectionObserver' in window&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches){
    steps.classList.add('reveal');
    var so=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){steps.classList.add('in');so.disconnect()}})},{threshold:.35});
    so.observe(steps);
  }

})();
