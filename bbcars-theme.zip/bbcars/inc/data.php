<?php
/**
 * BB Cars data: manufacturer approvals and insurance partners.
 * Edit these lists to add or remove approvals. Logo files live in assets/logos and assets/insurers.
 * 't' = shown as a text wordmark until official logo artwork is added (drop a PNG in assets/logos and set 'l').
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function bb_tall_logos() {
	return array( 'citroen', 'suzuki', 'opel', 'alfa-romeo', 'land-rover', 'chevrolet', 'peugeot', 'vw', 'mitsubishi', 'abarth', 'chery', 'renault', 'fiat', 'jeep' );
}

function bb_approvals() {
	return array(
		array( 'n' => 'Ford', 'l' => array( 'ford' ) ),
		array( 'n' => 'Haval / GWM', 'l' => array( 'haval', 'gwm' ) ),
		array( 'n' => 'Honda', 'l' => array( 'honda' ) ),
		array( 'n' => 'JAC', 't' => 'JAC' ),
		array( 'n' => 'Mitsubishi', 'l' => array( 'mitsubishi' ) ),
		array( 'n' => 'Renault', 'l' => array( 'renault' ) ),
		array( 'n' => 'Stellantis', 's' => 'Abarth, Alfa Romeo, Citroën, Fiat, Jeep, Opel and Peugeot', 'l' => array( 'abarth', 'alfa-romeo', 'citroen', 'fiat', 'jeep', 'opel', 'peugeot' ), 'g' => 'stellantis' ),
		array( 'n' => 'Chevrolet', 's' => 'Stellantis', 'l' => array( 'chevrolet' ), 'g' => 'stellantis' ),
		array( 'n' => 'Leap Motors', 's' => 'Stellantis', 'l' => array( 'leapmotor' ), 'g' => 'stellantis', 'ev' => 1 ),
		array( 'n' => 'Subaru', 'l' => array( 'subaru' ) ),
		array( 'n' => 'Suzuki', 'l' => array( 'suzuki' ) ),
		array( 'n' => 'Nissan', 'l' => array( 'nissan' ) ),
		array( 'n' => 'Hyundai', 't' => 'Hyundai' ),
		array( 'n' => 'Chery', 'l' => array( 'chery' ), 'g' => 'chery' ),
		array( 'n' => 'Omoda, Jaecoo & Lepas', 's' => 'Chery', 'l' => array( 'omoda', 'jaecoo', 'lepas' ), 'g' => 'chery' ),
		array( 'n' => 'I-Caur', 'l' => array( 'icaur' ), 'ev' => 1 ),
		array( 'n' => 'Jetour', 'l' => array( 'jetour' ) ),
		array( 'n' => 'Mahindra', 'l' => array( 'mahindra' ) ),
		array( 'n' => 'BAIC', 't' => 'BAIC' ),
		array( 'n' => 'Geely', 't' => 'Geely', 'ev' => 1 ),
		array( 'n' => 'MG', 't' => 'MG', 'ev' => 1, 'ce' => 1 ),
		array( 'n' => 'Kia', 'l' => array( 'kia' ) ),
		array( 'n' => 'Mercedes-Benz', 'l' => array( 'mercedes-benz' ), 'ev' => 1, 'ce' => 1 ),
		array( 'n' => 'Toyota', 'l' => array( 'toyota' ) ),
		array( 'n' => 'Audi', 'l' => array( 'audi' ) ),
		array( 'n' => 'VW', 'l' => array( 'vw' ) ),
		array( 'n' => 'Audi Aluminium', 'l' => array( 'audi' ), 'al' => 1 ),
		array( 'n' => 'VW Aluminium', 'l' => array( 'vw' ), 'al' => 1 ),
		array( 'n' => 'Jaguar', 'l' => array( 'jaguar' ), 'ev' => 1, 'ce' => 1 ),
		array( 'n' => 'Land Rover', 'l' => array( 'land-rover' ), 'ev' => 1, 'ce' => 1 ),
	);
}

/** Order of logos in the scrolling ribbon. Items starting with * are text wordmarks. */
function bb_ribbon() {
	return array( 'toyota', 'mercedes-benz', 'ford', 'vw', 'audi', 'land-rover', 'jaguar', 'kia', 'nissan', 'honda', '*Hyundai', 'stellantis', 'peugeot', 'citroen', 'jeep', 'fiat', 'alfa-romeo', 'abarth', 'opel', 'chevrolet', 'leapmotor', 'renault', 'mitsubishi', 'subaru', 'suzuki', 'haval', 'gwm', 'chery', 'omoda', 'jaecoo', 'lepas', 'icaur', 'jetour', 'mahindra', '*JAC', '*BAIC', '*Geely', '*MG' );
}

/** slug, name, square logo flag */
function bb_insurers() {
	return array(
		array( 'hollard', 'Hollard' ), array( 'old-mutual', 'Old Mutual' ), array( 'mutual-federal', 'Mutual & Federal Risk Financing' ), array( 'momentum', 'Momentum Insure' ), array( 'guardrisk', 'Guardrisk' ), array( 'auto-magic', 'Auto Magic' ),
		array( 'outsurance', 'OUTsurance', 1 ), array( 'standard-bank', 'Standard Bank Insure' ), array( 'discovery', 'Discovery' ), array( 'psg', 'PSG Insure' ), array( 'bidvest', 'Bidvest Insurance' ), array( 'santam', 'Santam' ),
		array( 'miway', 'MiWay' ), array( 'naked', 'Naked' ), array( 'indwe', 'Indwe Risk Services' ), array( 'marsh', 'Marsh' ), array( 'one', 'ONE' ), array( 'lockton', 'Lockton', 1 ),
		array( 'new-national', 'New National', 1 ), array( 'infiniti', 'Infiniti Insurance' ), array( 'genesis', 'Genesis Insurance Brokers' ), array( 'lombard', 'Lombard', 1 ), array( 'cib', 'cib' ), array( 'econorisk', 'Econorisk', 1 ),
		array( 'aig', 'AIG' ), array( 'frontline', 'Frontline', 1 ), array( 'bryte', 'Bryte' ), array( 'alpha', 'Alpha', 1 ), array( 'western', 'Western' ), array( 'integrisure', 'IntegriSure' ),
		array( 'tih', 'tih' ), array( 'renasa', 'Renasa' ), array( 'brolink', 'Brolink' ),
	);
}

function bb_logo_img( $slug, $dir = 'logos', $alt = '' ) {
	$cls = in_array( $slug, bb_tall_logos(), true ) ? 'tall' : '';
	return '<img src="' . esc_url( BB_URI . '/assets/' . $dir . '/' . $slug . '.png' ) . '" alt="' . esc_attr( $alt ) . '" class="' . $cls . '" loading="lazy" decoding="async">';
}

function bb_approval_card( $a ) {
	if ( ! empty( $a['t'] ) ) {
		$lg = '<span class="wordmark">' . esc_html( $a['t'] ) . '</span>';
	} else {
		$lg = '';
		foreach ( $a['l'] as $k ) { $lg .= bb_logo_img( $k ); }
	}
	$multi = ( ! empty( $a['l'] ) && count( $a['l'] ) > 1 ) ? ' multi' : '';
	$tags  = '';
	if ( ! empty( $a['ev'] ) ) { $tags .= '<span class="tag ev">' . ( ! empty( $a['ce'] ) ? 'EV &amp; Combustion' : 'EV' ) . '</span>'; }
	if ( ! empty( $a['al'] ) ) { $tags .= '<span class="tag al">Aluminium</span>'; }
	$search = strtolower( $a['n'] . ' ' . ( isset( $a['s'] ) ? $a['s'] : '' ) . ' ' . ( isset( $a['l'] ) ? implode( ' ', $a['l'] ) : '' ) );
	$out  = '<div class="mcard" data-name="' . esc_attr( $search ) . '" data-ev="' . ( empty( $a['ev'] ) ? 0 : 1 ) . '" data-al="' . ( empty( $a['al'] ) ? 0 : 1 ) . '" data-g="' . esc_attr( isset( $a['g'] ) ? $a['g'] : '' ) . '">';
	$out .= '<div class="lg' . $multi . '">' . $lg . '</div><div class="nm">' . esc_html( $a['n'] );
	if ( ! empty( $a['s'] ) ) { $out .= '<span class="sub">' . esc_html( $a['s'] ) . '</span>'; }
	if ( $tags ) { $out .= '<div class="tags">' . $tags . '</div>'; }
	$out .= '</div></div>';
	return $out;
}
