BB Cars Auto Body – WordPress theme (v1.0.0)
Built by iNCO Creative

INSTALL
1. WordPress admin › Appearance › Themes › Add New › Upload Theme › choose bbcars-theme.zip › Install › Activate.
2. On activation the theme creates a "Manufacturer Approvals" page (/manufacturer-approvals/) using the
   "Manufacturer Approvals" template. The homepage (front-page.php) is used automatically.
3. Settings › Reading: "Your homepage displays" can stay on "Your latest posts" or be set to any static page.

EDIT CONTENT (Appearance › Customize)
- BB Cars – Contact details: reception/Jakes phones, the three email addresses, address, Instagram handle,
  and the address quote requests are emailed to (default Reception@bbcars.co.za).
- BB Cars – Hellopeter reviews: paste the review-feed widget embed code from Hellopeter Business
  (biz.hellopeter.com › Widgets). Until it is pasted, the section shows the review button + QR code.
- BB Cars – Hero slider images: replace any of the three slide backgrounds.
- Site Identity: optional custom logo (defaults to the white BB Cars logo in assets/img).
- Menus: optionally assign a menu to "Main menu"; otherwise the built-in section links are used.

APPROVALS AND INSURERS
- Lists live in inc/data.php. Logos are white PNGs in assets/logos and assets/insurers.
- JAC, Hyundai, BAIC, Geely and MG show as text wordmarks until official logo files are supplied:
  add e.g. assets/logos/hyundai.png (white on transparent, ~120px tall) and change
  array( 'n' => 'Hyundai', 't' => 'Hyundai' ) to array( 'n' => 'Hyundai', 'l' => array( 'hyundai' ) ).

QUOTE FORM
- Posts to admin-post.php (action bb_quote) with nonce + honeypot and sends via wp_mail with up to 6 photos attached.
- Install an SMTP plugin (e.g. WP Mail SMTP) on the host so emails are delivered reliably.
