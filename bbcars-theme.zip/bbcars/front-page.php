<?php
/**
 * Front page
 *
 * @package bbcars
 */
get_header();
?>

<!-- HERO SLIDER -->
<section class="hero" id="hero" aria-roledescription="carousel" aria-label="BB Cars highlights">
  <div class="slides">
    <article class="slide on" aria-roledescription="slide" aria-label="1 of 3">
      <div class="bg" style="background-image:url(<?php echo esc_url( bb_slide_img( 1, 'hero-workshop.jpg' ) ); ?>);background-position:62% 60%"></div>
      <div class="shade"></div>
      <div class="blade a"></div><div class="blade b"></div><div class="blade c"></div>
      <div class="wrap inner">
        <span class="kicker anim">OEM-approved auto body repair centre</span>
        <h1 class="anim">Driven by standards. <span class="r">Defined by quality.</span></h1>
        <p class="sub anim">Every vehicle restored to exact manufacturer specifications, by a team that keeps you informed from drop-off to collection.</p>
        <div class="btns anim"><a class="btn" href="<?php echo esc_url( bb_home_anchor( 'contact' ) ); ?>">Request a quote <svg><use href="#i-arrow"/></svg></a><a class="btn ghost" href="<?php echo esc_attr( bb_tel( 'reception_phone' ) ); ?>"><svg><use href="#i-phone"/></svg>Call reception</a></div>
      </div>
    </article>
    <article class="slide" aria-roledescription="slide" aria-label="2 of 3" aria-hidden="true">
      <div class="bg" style="background-image:url(<?php echo esc_url( bb_slide_img( 2, 'building.jpg' ) ); ?>);background-position:50% 40%"></div>
      <div class="shade"></div>
      <div class="blade a"></div><div class="blade c"></div>
      <div class="wrap inner">
        <span class="kicker anim">Since 1981 · Wynberg, Sandton</span>
        <div class="h1 anim" role="heading" aria-level="2">Setting the benchmark <span class="r">in automotive repair</span></div>
        <p class="sub anim">Over four decades of trusted repairs from a 3,000m² purpose-built facility, with 70 highly skilled professionals.</p>
        <div class="btns anim"><a class="btn" href="<?php echo esc_url( bb_home_anchor( 'about' ) ); ?>">Discover BB Cars <svg><use href="#i-arrow"/></svg></a><a class="btn ghost" href="<?php echo esc_url( bb_home_anchor( 'insurers' ) ); ?>">Our insurance partners</a></div>
      </div>
    </article>
    <article class="slide" aria-roledescription="slide" aria-label="3 of 3" aria-hidden="true">
      <div class="bg" style="background-image:url(<?php echo esc_url( bb_slide_img( 3, 'bays.jpg' ) ); ?>);background-position:50% 55%"></div>
      <div class="shade"></div>
      <div class="blade a"></div><div class="blade b"></div>
      <div class="wrap inner">
        <span class="kicker anim">98% customer satisfaction (CSI)</span>
        <div class="h1 anim" role="heading" aria-level="2">Customer care <span class="r">at every step</span></div>
        <p class="sub anim">Regular updates during your repair, a quality inspection before handover and a follow-up call after collection.</p>
        <div class="btns anim"><a class="btn" href="<?php echo esc_url( bb_home_anchor( 'customer-care' ) ); ?>">Our service promise <svg><use href="#i-arrow"/></svg></a><a class="btn ghost" href="<?php echo esc_url( bb_home_anchor( 'reviews' ) ); ?>">Read our reviews</a></div>
      </div>
    </article>
  </div>
  <div class="hero-ui">
    <div class="wrap">
      <div class="dots" role="tablist" aria-label="Choose slide">
        <button class="dot on" role="tab" aria-selected="true" aria-label="Slide 1"><span class="bar"><i></i></span><span class="lbl">Driven by standards</span></button>
        <button class="dot" role="tab" aria-selected="false" aria-label="Slide 2"><span class="bar"><i></i></span><span class="lbl">Since 1981</span></button>
        <button class="dot" role="tab" aria-selected="false" aria-label="Slide 3"><span class="bar"><i></i></span><span class="lbl">Customer care</span></button>
      </div>
      <div class="arrows">
        <button class="arrow" id="prev" aria-label="Previous slide"><svg><use href="#i-left"/></svg></button>
        <button class="arrow" id="next" aria-label="Next slide"><svg><use href="#i-right"/></svg></button>
      </div>
    </div>
  </div>
</section>

<!-- MANUFACTURER RIBBON -->
<section class="ribbon" aria-label="Manufacturer approvals">
  <div class="wrap head">
    <p><b>30+ OEM approvals</b> · approved by the world's leading manufacturers</p>
    <a href="<?php echo esc_url( bb_approvals_url() ); ?>">View all approvals <svg><use href="#i-arrow"/></svg></a>
  </div>
  <div class="marquee"><div class="track">
      <?php
      $bb_items = '';
      foreach ( bb_ribbon() as $bb_k ) {
        $bb_items .= ( '*' === $bb_k[0] ) ? '<span class="wordmark">' . esc_html( substr( $bb_k, 1 ) ) . '</span>' : bb_logo_img( $bb_k, 'logos', ucwords( str_replace( '-', ' ', $bb_k ) ) );
      }
      echo $bb_items; // phpcs:ignore -- escaped above
      echo str_replace( '<img ', '<img aria-hidden="true" ', preg_replace( '/alt="[^"]*"/', 'alt=""', $bb_items ) ); // phpcs:ignore -- duplicate for seamless loop
      ?>
    </div></div>
</section>

<!-- ABOUT -->
<section class="pad" id="about">
  <div class="wrap about">
    <div class="copy">
      <span class="eyebrow">About BB Cars</span>
      <h2>Setting the benchmark<br><span class="r">in automotive repair</span></h2>
      <p>For over four decades, BB Cars has earned a reputation as one of South Africa's leading OEM-approved autobody repair centres. Combining highly skilled technicians with advanced repair technologies, we restore every vehicle to exact manufacturer specifications, ensuring uncompromising safety, quality and performance.</p>
      <p>Whether repairing luxury vehicles, commercial fleets or the latest electric and hybrid models, our commitment remains the same: precision without compromise.</p>
      <div class="btns" style="margin-top:6px"><a class="btn dark" href="<?php echo esc_url( bb_home_anchor( 'services' ) ); ?>">Our repair solutions <svg><use href="#i-arrow"/></svg></a><a class="btn line" href="<?php echo esc_url( bb_home_anchor( 'contact' ) ); ?>">Book an assessment</a></div>
    </div>
    <div class="photo">
      <img src="<?php echo esc_url( BB_URI ); ?>/assets/img/building.jpg" alt="The BB Cars Auto Body building at 18 5th Street, Wynberg" loading="lazy">
      <div class="badge"><b>40+</b><span>Years of<br>experience</span></div>
    </div>
  </div>
</section>

<!-- LEGACY STATS -->
<section class="legacy pad" aria-labelledby="legacy-h" style="padding-top:clamp(64px,7vw,96px)">
  <div class="wrap">
    <div class="tabbox">
      <h2 class="tab" id="legacy-h">A legacy of <span class="r">excellence</span></h2>
      <div class="stats-wrap">
        <div class="stats">
          <div class="stat"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 9h18M8 2v4M16 2v4M7 13h2M11 13h2M15 13h2M7 17h2M11 17h2"/></svg><b>1981</b><span>Established</span></div>
          <div class="stat"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="9" r="6"/><path d="m12 6 1 2 2 .3-1.5 1.4.4 2.1L12 10.8l-1.9 1 .4-2.1L9 8.3l2-.3zM8.5 14 7 22l5-3 5 3-1.5-8"/></svg><b>40+</b><span>Years of experience</span></div>
          <div class="stat"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 21h18M5 21V8l5-3v16M10 21V3l9 4v14M13 9h3M13 12h3M13 15h3M6.5 11h1.5M6.5 14h1.5"/></svg><b>3,000m²</b><span>Purpose-built facility</span></div>
          <div class="stat"><svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="7" r="3.2"/><circle cx="5" cy="9" r="2.4"/><circle cx="19" cy="9" r="2.4"/><path d="M6 20c0-3.6 2.7-6.5 6-6.5s6 2.9 6 6.5zM0.5 19c0-2.6 1.9-4.7 4.5-4.7 1 0 1.9.3 2.6.8A8 8 0 0 0 5 19zM23.5 19c0-2.6-1.9-4.7-4.5-4.7-1 0-1.9.3-2.6.8A8 8 0 0 1 19 19z"/></svg><b>70</b><span>Highly skilled professionals</span></div>
          <div class="stat"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M5 11 6.6 6.4A2 2 0 0 1 8.5 5h7a2 2 0 0 1 1.9 1.4L19 11a2 2 0 0 1 2 2v5h-2v1.5a1 1 0 0 1-1 1h-1.5a1 1 0 0 1-1-1V18h-7v1.5a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V18H3v-5a2 2 0 0 1 2-2zm2.2 0h9.6l-1.2-3.4a1 1 0 0 0-.9-.6H9.3a1 1 0 0 0-.9.6zM6.5 15.5a1.3 1.3 0 1 0 0-2.6 1.3 1.3 0 0 0 0 2.6zm11 0a1.3 1.3 0 1 0 0-2.6 1.3 1.3 0 0 0 0 2.6z"/></svg><b>180–200</b><span>Vehicles repaired monthly</span></div>
          <div class="stat"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 2 4 5v6c0 5 3.4 9.4 8 11 4.6-1.6 8-6 8-11V5z"/><path d="m8.5 12 2.5 2.5 4.5-5"/></svg><b>30+</b><span>OEM manufacturer approvals</span></div>
          <div class="stat"><svg viewBox="0 0 24 24"><use href="#i-star"/></svg><b>98%</b><span>Customer satisfaction (CSI)</span></div>
          <div class="stat"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 17v-4l2.5-5h10l3.5 5h1a2 2 0 0 1 2 2v2h-2"/><circle cx="7" cy="17.5" r="2"/><circle cx="17" cy="17.5" r="2"/><path d="M9 17.5h6"/><path d="M19 2l-2 3.5h3L18 9" stroke-width="1.6"/><text x="7.4" y="13.2" font-size="4.2" font-family="Arial" font-weight="700" fill="currentColor" stroke="none">EV</text></svg><b>EV &amp; Hybrid</b><span>Certified repair centre</span></div>
        </div>
        <div class="top-perf">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M7 3h10v6a5 5 0 0 1-10 0zM7 5H4v1.5A3.5 3.5 0 0 0 7.5 10M17 5h3v1.5A3.5 3.5 0 0 1 16.5 10M12 14v3M8 21h8l-1-4H9z"/><path d="m12 5 .8 1.6 1.7.2-1.2 1.2.3 1.7-1.6-.8-1.6.8.3-1.7-1.2-1.2 1.7-.2z" fill="currentColor"/></svg>
          <h3>Top performing repairer</h3>
          <p>Consistently recognised amongst South Africa's top-performing autobody repair centres by:</p>
          <ul><li>Discovery</li><li>OUTsurance</li><li>Lightstone</li><li>The Panel Beater Directory</li></ul>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CUSTOMER SERVICE -->
<section class="care pad" id="customer-care">
  <div class="bgimg" aria-hidden="true"></div>
  <div class="wrap">
    <div class="split-head">
      <h2>Our commitment to quality<br><span class="r">&amp; customer satisfaction</span></h2>
      <div class="rule"><p class="lede">Before every vehicle leaves our facility, it undergoes rigorous quality inspections to ensure it meets both manufacturer standards and our own uncompromising expectations. You deal with people who care how your car comes back, and how you were treated along the way.</p></div>
    </div>
    <div class="pillars">
      <div class="pillar"><div class="shield"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 21l1.9-5.4A8 8 0 1 1 21 12z"/><path d="M8 12h.01M12 12h.01M16 12h.01" stroke-width="3"/></svg></div><h3>Customer communication</h3><p>Regular customer updates throughout the repair process, so you always know where your vehicle is.</p></div>
      <div class="pillar"><div class="shield"><svg viewBox="0 0 24 24"><use href="#i-phone"/></svg></div><h3>Customer aftercare</h3><p>Follow-up calls after vehicle collection to ensure complete customer satisfaction.</p></div>
      <div class="pillar"><div class="shield"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2 4 5v6c0 5 3.4 9.4 8 11 4.6-1.6 8-6 8-11V5z"/><path d="m8.5 12 2.5 2.5 4.5-5"/></svg></div><h3>Warranty assurance</h3><p>A 1-year warranty on repairs and approximately a 5-year warranty on paintwork.</p></div>
      <div class="pillar"><div class="shield"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="3" width="18" height="12" rx="1.5"/><path d="M7 21l5-6 5 6M8 10l3-3 2 2 3-3"/></svg></div><h3>Technical excellence</h3><p>Ongoing investment in welding, panel beating and manufacturer-specific training programmes.</p></div>
      <div class="pillar"><div class="shield"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 16v-3l2-4h12l2 4v3z"/><circle cx="7.5" cy="16.5" r="1.5"/><circle cx="16.5" cy="16.5" r="1.5"/><path d="m9 6 2 2 4-4"/></svg></div><h3>OEM compliance</h3><p>Maintaining manufacturer approvals while continually updating our skills and equipment to repair the latest models to exact specifications.</p></div>
      <div class="pillar"><div class="shield"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 17l6-6 4 4 8-8"/><path d="M14 7h7v7"/></svg></div><h3>Continuous improvement</h3><p>A strong commitment to quality workmanship, innovation and industry-leading repair standards.</p></div>
    </div>

    <div class="journey">
      <h3>Your repair, <span class="r">step by step</span></h3>
      <ol class="steps">
        <li><b>Assessment &amp; quote</b><span>Bring your vehicle in or send us the details for an accurate assessment.</span></li>
        <li><b>Claims handled</b><span>We work directly with your insurer for seamless claims management.</span></li>
        <li><b>Repair &amp; updates</b><span>OEM methods and equipment, with regular progress updates from our team.</span></li>
        <li><b>Quality inspection</b><span>Every vehicle is checked against manufacturer and BB Cars standards.</span></li>
        <li><b>Handover &amp; follow-up</b><span>Collection, warranty cover and a follow-up call to make sure you're satisfied.</span></li>
      </ol>
    </div>

    <div class="care-cta">
      <div><h3>Been in an accident?</h3><p>Speak to our reception team and we'll guide you through the next steps.</p></div>
      <div class="btns"><a class="btn white" href="<?php echo esc_attr( bb_tel( 'reception_phone' ) ); ?>"><svg><use href="#i-phone"/></svg><?php bb_e( 'reception_phone' ); ?></a><a class="btn dark" href="<?php echo esc_url( bb_home_anchor( 'contact' ) ); ?>">Request a quote</a></div>
    </div>
  </div>
</section>

<!-- INSURANCE (centre section) -->
<section class="insure pad" id="insurers">
  <div class="wrap">
    <div class="split-head" style="padding-top:30px">
      <h2>Our insurance<br>partners</h2>
      <div class="rule"><p class="lede">BB Cars partners with South Africa's leading insurers, underwriting managers, brokerages and fleet management companies. In addition to our direct insurer approvals, we are an approved repairer for numerous broker panels underwritten by these insurers, providing seamless claims management and trusted repair solutions for policyholders nationwide.</p></div>
    </div>
    <div class="ins-grid">
      <?php foreach ( bb_insurers() as $bb_i ) : ?>
        <div class="ins" title="<?php echo esc_attr( $bb_i[1] ); ?>"><img src="<?php echo esc_url( BB_URI . '/assets/insurers/' . $bb_i[0] . '.png' ); ?>" alt="<?php echo esc_attr( $bb_i[1] ); ?>" class="<?php echo empty( $bb_i[2] ) ? '' : 'sq'; ?>" loading="lazy" decoding="async"></div>
      <?php endforeach; ?>
    </div>
    <div class="ins-foot">
      <p>Insured with one of our partners? Tell your insurer you'd like BB Cars to handle your repair, or contact us and we'll help with the claim.</p>
      <div class="btns"><a class="btn white" href="<?php echo esc_url( bb_home_anchor( 'contact' ) ); ?>">Start my claim repair <svg><use href="#i-arrow"/></svg></a></div>
    </div>
  </div>
</section>

<!-- SERVICES -->
<section class="pad" id="services">
  <div class="wrap">
    <div class="tabbox">
      <h2 class="tab">Comprehensive repair <span class="r">solutions</span></h2>
      <div class="svc-grid">
        <div class="svc"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M2 14.5 3.3 11a1.6 1.6 0 0 1 1.5-1h5.4a1.6 1.6 0 0 1 1.5 1l1.3 3.5a1.5 1.5 0 0 1 1 1.4V19h-1.5v1a.8.8 0 0 1-.8.8H10.5a.8.8 0 0 1-.8-.8v-1H5.3v1a.8.8 0 0 1-.8.8H3.3a.8.8 0 0 1-.8-.8v-1H1v-3.1a1.5 1.5 0 0 1 1-1.4zm2.1-.2h6.8l-.9-2.6H5zM12.5 8.2 13.8 4.7a1.6 1.6 0 0 1 1.5-1h5.4a1.6 1.6 0 0 1 1.5 1l1.3 3.5a1.5 1.5 0 0 1 .5 1.1V13h-1.5v.8a.8.8 0 0 1-.8.8h-1.2a.8.8 0 0 1-.8-.8V13h-1.3l-.8-2.2a2.8 2.8 0 0 0-1.6-1.6zm2.1-.2h6.8l-.9-2.6h-5z"/></svg><h3>Collision repair</h3><ul><li>Structural repairs</li><li>Chassis alignment</li><li>Major &amp; minor collision repairs</li></ul></div>
        <div class="svc"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M14 4h4l2 3h-6zM13 7h8v3a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2zM16 12v3l-2 7M10 7H6M4 5l-1-1M4 9 3 10M5 7H2" /></svg><h3>Refinishing</h3><ul><li>Premium spray painting</li><li>Paint correction</li><li>Paint protection film (PPF)</li><li>Ceramic coating preparation</li></ul></div>
        <div class="svc"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2l4 4-9 9-4-4z"/><path d="M9 11 4 16c-1 1-1 3 0 4s3 1 4 0l5-5"/><path d="M6 18l2-2"/></svg><h3>Specialist services</h3><ul><li>Paintless dent removal</li><li>Hail damage restoration</li><li>Plastic welding</li><li>Vehicle wraps</li><li>Glass polishing</li></ul></div>
        <div class="svc"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M13.5 1 4 13.5h6.5L9 23l11-13.5h-7z"/></svg><h3>Future mobility</h3><ul><li>EV &amp; hybrid repairs</li><li>High-voltage safety</li><li>Aluminium repairs</li><li>Carbon fibre repairs</li></ul></div>
      </div>
    </div>
    <div class="ev-band">
      <img src="<?php echo esc_url( BB_URI ); ?>/assets/img/bays.jpg" alt="Inside the BB Cars repair facility" loading="lazy">
      <div class="txt">
        <span class="eyebrow">EV &amp; hybrid certified</span>
        <h3 style="font-size:clamp(1.8rem,3vw,2.5rem)">Ready for the vehicles of <span class="r">today and tomorrow</span></h3>
        <p>From luxury vehicles and commercial fleets to the latest electric and hybrid models, our technicians repair to exact OEM specifications with high-voltage safety procedures, aluminium and carbon fibre expertise.</p>
        <div class="btns"><a class="btn" href="<?php echo esc_url( bb_approvals_url() ); ?>">See EV approvals <svg><use href="#i-arrow"/></svg></a></div>
      </div>
    </div>
  </div>
</section>

<!-- MANUFACTURERS -->
<section class="mfr pad" id="manufacturers">
  <div class="bgimg" aria-hidden="true"></div>
  <div class="wrap">
    <div class="split-head">
      <h2>Approved by the world's<br><span class="r">leading manufacturers</span></h2>
      <div class="rule"><p class="lede">BB Cars maintains over 30 manufacturer approvals, ensuring repairs are carried out to exact OEM specifications using approved methods and equipment.</p></div>
    </div>
    <div class="mfr-grid preview">
      <?php foreach ( bb_approvals() as $bb_a ) { echo bb_approval_card( $bb_a ); } // phpcs:ignore -- escaped in helper ?>
    </div>
    <div class="more"><a class="btn" href="<?php echo esc_url( bb_approvals_url() ); ?>">View all manufacturer approvals <svg><use href="#i-arrow"/></svg></a></div>
  </div>
</section>

<!-- ESG -->
<section class="esg pad" aria-labelledby="esg-h">
  <div class="wrap">
    <div class="split-head">
      <h2 id="esg-h">ESG &amp; <span class="r">sustainability</span></h2>
      <div class="rule"><p>We continually invest in environmentally responsible repair methods, advanced technologies and sustainable practices that reduce our environmental impact while maintaining the highest manufacturer standards.</p></div>
    </div>
    <div class="esg-row">
      <div class="esg-item"><svg viewBox="0 0 48 48" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round"><path d="M10 14h16l3 6H14zM20 20v8l-6 14M29 17h4M14 6l2 8"/><circle cx="37" cy="14" r="1.4" fill="#E0202A" stroke="none"/><circle cx="41" cy="18" r="1.4" fill="#E0202A" stroke="none"/><circle cx="41" cy="11" r="1.4" fill="#E0202A" stroke="none"/><circle cx="45" cy="15" r="1.4" fill="#E0202A" stroke="none"/></svg><b>Waterborne paint systems</b></div>
      <div class="esg-item"><svg viewBox="0 0 48 48" fill="none" stroke-width="2" stroke-linecap="round"><path d="M40 24a16 16 0 0 1-27 11.6M8 24A16 16 0 0 1 35 12.4" stroke="#fff"/><path d="M35 6v7h-7M13 42v-7h7" stroke="#fff"/><path d="M16 30c0-9 7-14 16-14 0 10-6 16-14 16" stroke="#E0202A"/><path d="M18 30l8-8" stroke="#E0202A"/></svg><b>Responsible resource management</b></div>
      <div class="esg-item"><svg viewBox="0 0 48 48" fill="none" stroke-width="2"><circle cx="22" cy="24" r="16" stroke="#fff"/><path d="M8 20c6 0 6 6 12 6s2 8 6 10M16 9c2 4 8 3 8 8s6 3 9 0" stroke="#fff"/><path d="M30 38c0-7 5-11 12-11 0 7-4 12-11 12M32 37l6-6" stroke="#E0202A" stroke-linecap="round"/></svg><b>Environmentally conscious processes</b></div>
      <div class="esg-item"><svg viewBox="0 0 48 48" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 36v-6l4-8h18l6 8h4a3 3 0 0 1 3 3v3h-3"/><circle cx="11" cy="37" r="3"/><circle cx="30" cy="37" r="3"/><path d="M14 37h13M30 14l6-6 5 3-3 8M36 8l-2-4" /><circle cx="41" cy="11" r="1.6" fill="#E0202A" stroke="none"/><path d="M38 19l-4 6" stroke="#E0202A"/></svg><b>Future-ready repair technologies</b></div>
    </div>
  </div>
</section>

<!-- REVIEWS -->
<section class="reviews pad" id="reviews">
  <div class="wrap">
    <div class="split-head">
      <h2>What our customers<br><span class="r">say about us</span></h2>
      <div class="rule"><p class="lede">Customer satisfaction is how we measure every repair. Read live, independent reviews from BB Cars customers on Hellopeter, or share your own experience.</p></div>
    </div>
    <div class="rev-grid">
      <div class="feed" aria-label="Hellopeter live reviews">
        <div class="feed-head">
          <span class="live"><i></i>Live reviews</span>
          <span class="hp-word">he<u>ll</u>opeter</span>
        </div>
         <?php $bb_code = bb_opt( 'hellopeter_code' ); if ( $bb_code ) : ?>
        <div class="hp-embed"><?php echo $bb_code; // phpcs:ignore -- admin-supplied widget embed (unfiltered_html) ?></div>
        <?php else : ?>
        <div class="hp-empty"><p>Read what BB Cars customers say about their repairs, or share your own experience, on Hellopeter.</p></div>
        <?php endif; ?>
        <div class="btns"><a class="btn" href="<?php echo esc_url( bb_opt( 'hellopeter_url' ) ); ?>" target="_blank" rel="noopener"><svg><use href="#i-star"/></svg>Review us on Hellopeter</a></div>
      </div>
      <aside class="hp-card">
        <div class="csi"><b>98%</b><span>Customer<br>satisfaction (CSI)</span></div>
        <p style="color:#c9cbd0">Had your vehicle repaired with us? Your feedback helps us keep improving.</p>
        <div class="qr"><img src="<?php echo esc_url( BB_URI ); ?>/assets/img/hellopeter-qr.png" alt="QR code to review BB Cars on Hellopeter" width="112" height="112"><p>Scan to leave a review<small>Opens BB Cars on Hellopeter</small></p></div>
      </aside>
    </div>
  </div>
</section>

<!-- CONTACT -->
<section class="pad" id="contact">
  <div class="wm" aria-hidden="true"><div class="wm-track"><span class="wm-logo"></span><span class="wm-logo"></span><span class="wm-logo"></span><span class="wm-logo"></span><span class="wm-logo"></span><span class="wm-logo"></span><span class="wm-logo"></span><span class="wm-logo"></span></div></div>
  <div class="wrap">
    <div class="split-head">
      <h2>Contact <span class="r">us</span></h2>
      <div class="rule"><p class="lede">Call reception, email the team or send your details for a quote. We'll get back to you promptly.</p></div>
    </div>
    <div class="contact-grid">
      <div class="cinfo">
        <div class="crow"><span class="ic"><svg><use href="#i-pin"/></svg></span><div><div class="k">Visit us</div><div class="v"><?php bb_e( 'address_1' ); ?>,<br><?php bb_e( 'address_2' ); ?><br><a class="dir" href="https://www.google.com/maps/search/?api=1&amp;query=BB+Cars+Auto+Body+18+5th+Street+Wynberg+Sandton" target="_blank" rel="noopener">Get directions →</a></div></div></div>
        <div class="crow"><span class="ic"><svg><use href="#i-phone"/></svg></span><div><div class="k">Call us</div><div class="v lines"><span>Reception · <a href="<?php echo esc_attr( bb_tel( 'reception_phone' ) ); ?>"><?php bb_e( 'reception_phone' ); ?></a></span><span>Jakes · <a href="<?php echo esc_attr( bb_tel( 'jakes_phone' ) ); ?>"><?php bb_e( 'jakes_phone' ); ?></a></span></div></div></div>
        <div class="crow"><span class="ic"><svg><use href="#i-mail"/></svg></span><div><div class="k">Email us</div><div class="v lines"><span><a href="<?php echo esc_attr( bb_mailto( 'reception_email' ) ); ?>"><?php bb_e( 'reception_email' ); ?></a></span><span><a href="<?php echo esc_attr( bb_mailto( 'accounts_email' ) ); ?>"><?php bb_e( 'accounts_email' ); ?></a></span><span><a href="<?php echo esc_attr( bb_mailto( 'jakes_email' ) ); ?>"><?php bb_e( 'jakes_email' ); ?></a></span></div></div></div>
        <div class="ig"><img src="<?php echo esc_url( BB_URI ); ?>/assets/img/instagram-qr.png" alt="Instagram QR code for <?php echo esc_html( '@' . ltrim( bb_opt( 'instagram' ), '@' ) ); ?>" width="116" height="116"><div><b><?php echo esc_html( '@' . ltrim( bb_opt( 'instagram' ), '@' ) ); ?></b><p>Scan to follow us on Instagram for before-and-after repairs and workshop updates.</p><a href="<?php echo esc_url( bb_ig_url() ); ?>" target="_blank" rel="noopener"><?php echo esc_html( 'instagram.com/' . ltrim( bb_opt( 'instagram' ), '@' ) ); ?></a></div></div>
      </div>
      <form class="form<?php echo ( isset( $_GET['quote'] ) && 'sent' === $_GET['quote'] ) ? ' sent' : ''; // phpcs:ignore ?>" id="quoteForm" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
        <input type="hidden" name="action" value="bb_quote">
        <?php wp_nonce_field( 'bb_quote', 'bb_nonce' ); ?>
        <div class="hp-field" aria-hidden="true"><label for="q-website">Website</label><input id="q-website" name="website" tabindex="-1" autocomplete="off"></div>
        <h3>Request a <span class="r">quote</span></h3>
        <div class="row">
          <div class="field"><label for="q-name">Full name</label><input id="q-name" name="name" autocomplete="name" required></div>
          <div class="field"><label for="q-phone">Phone number</label><input id="q-phone" name="phone" type="tel" autocomplete="tel" required></div>
        </div>
        <div class="row">
          <div class="field"><label for="q-email">Email</label><input id="q-email" name="email" type="email" autocomplete="email"></div>
          <div class="field"><label for="q-vehicle">Vehicle make &amp; model</label><input id="q-vehicle" name="vehicle" placeholder="e.g. Toyota Corolla Cross"></div>
        </div>
        <div class="row">
          <div class="field"><label for="q-insurer">Insurer</label><select id="q-insurer" name="insurer"><option value="">Select your insurer</option><option>Private / not claiming</option><?php foreach ( bb_insurers() as $bb_i ) : ?><option><?php echo esc_html( $bb_i[1] ); ?></option><?php endforeach; ?></select></div>
          <div class="field"><label for="q-claim">Claim number (if any)</label><input id="q-claim" name="claim"></div>
        </div>
        <div class="field"><label for="q-msg">Tell us about the damage</label><textarea id="q-msg" name="message" placeholder="Briefly describe what happened and the damage"></textarea></div>
        <div class="field"><label for="q-photos">Photos of the damage (optional)</label><input id="q-photos" name="photos[]" type="file" accept="image/*" multiple></div>
        <button class="btn" type="submit" style="justify-self:start">Send my request <svg><use href="#i-arrow"/></svg></button>
        <p class="ok" role="status">Thank you. Your request has been sent to our reception team and we'll contact you shortly.</p>
        <?php if ( isset( $_GET['quote'] ) && 'error' === $_GET['quote'] ) : // phpcs:ignore ?><p class="err" role="alert">Your request could not be sent. Please check your name and phone number, or call reception on <?php bb_e( 'reception_phone' ); ?>.</p><?php endif; ?>
      </form>
    </div>
  </div>
</section>

<?php get_footer();
