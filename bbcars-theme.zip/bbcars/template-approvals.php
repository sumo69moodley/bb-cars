<?php
/**
 * Template Name: Manufacturer Approvals
 *
 * @package bbcars
 */
get_header();
?>
<section class="approvals-view page-mode" id="approvals" aria-labelledby="ap-h">
    <div class="wrap">
    <div class="intro">
      <span class="eyebrow">Manufacturer approvals</span>
      <h1 id="ap-h">All our <span class="r">OEM approvals</span></h1>
      <p class="lede" style="color:#c9cbd0">BB Cars maintains over 30 manufacturer approvals, so your vehicle is repaired to exact OEM specifications using approved methods and equipment, including electric, hybrid and aluminium-body vehicles.</p>
      <div class="controls">
        <label class="sr" for="apSearch">Search manufacturers</label>
        <input id="apSearch" type="search" placeholder="Search your vehicle brand, e.g. Toyota" autocomplete="off">
        <div class="chips" role="group" aria-label="Filter approvals">
          <button class="chip" data-f="all" aria-pressed="true">All</button>
          <button class="chip" data-f="ev" aria-pressed="false">EV approved</button>
          <button class="chip" data-f="al" aria-pressed="false">Aluminium</button>
          <button class="chip" data-f="stellantis" aria-pressed="false">Stellantis</button>
          <button class="chip" data-f="chery" aria-pressed="false">Chery group</button>
        </div>
      </div>
      <p class="count" id="apCount" aria-live="polite"></p>
    </div>
    <div class="mfr-grid" id="apGrid">
      <?php foreach ( bb_approvals() as $bb_a ) { echo bb_approval_card( $bb_a ); } // phpcs:ignore -- escaped in helper ?>
    </div>
    <p class="empty" id="apEmpty" hidden>No approval matches that search. Call reception on <?php bb_e( 'reception_phone' ); ?> and we'll confirm whether we can repair your vehicle.</p>
    <div class="btns" style="margin-top:36px"><a class="btn" href="<?php echo esc_url( home_url( '/#contact' ) ); ?>">Request a quote <svg><use href="#i-arrow"/></svg></a><a class="btn ghost" href="<?php echo esc_attr( bb_tel( 'reception_phone' ) ); ?>"><svg><use href="#i-phone"/></svg><?php bb_e( 'reception_phone' ); ?></a></div>
  </div>
</section>

<?php get_footer();
