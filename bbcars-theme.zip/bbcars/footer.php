</main>

<footer class="footer">
  <div class="wrap">
    <div class="fgrid">
      <div>
        <img class="logo" src="<?php echo esc_url( BB_URI ); ?>/assets/img/logo-white.png" alt="<?php bloginfo( 'name' ); ?>">
        <p class="tagline">Driven by standards.<br><span>Defined by quality.</span></p>
        <p style="margin-top:10px">OEM-approved auto body repair centre since 1981.</p>
      </div>
      <div><h4>Explore</h4><ul><li><a href="<?php echo esc_url( bb_home_anchor( 'about' ) ); ?>">About us</a></li><li><a href="<?php echo esc_url( bb_home_anchor( 'customer-care' ) ); ?>">Customer care</a></li><li><a href="<?php echo esc_url( bb_home_anchor( 'services' ) ); ?>">Repair solutions</a></li><li><a href="<?php echo esc_url( bb_approvals_url() ); ?>">Manufacturer approvals</a></li><li><a href="<?php echo esc_url( bb_home_anchor( 'insurers' ) ); ?>">Insurance partners</a></li><li><a href="<?php echo esc_url( bb_home_anchor( 'reviews' ) ); ?>">Reviews</a></li></ul></div>
      <div><h4>Contact</h4><ul><li>Reception · <a href="<?php echo esc_attr( bb_tel( 'reception_phone' ) ); ?>"><?php bb_e( 'reception_phone' ); ?></a></li><li>Jakes · <a href="<?php echo esc_attr( bb_tel( 'jakes_phone' ) ); ?>"><?php bb_e( 'jakes_phone' ); ?></a></li><li><a href="<?php echo esc_attr( bb_mailto( 'reception_email' ) ); ?>"><?php bb_e( 'reception_email' ); ?></a></li><li><a href="<?php echo esc_attr( bb_mailto( 'accounts_email' ) ); ?>"><?php bb_e( 'accounts_email' ); ?></a></li><li><a href="<?php echo esc_attr( bb_mailto( 'jakes_email' ) ); ?>"><?php bb_e( 'jakes_email' ); ?></a></li></ul></div>
      <div><h4>Visit</h4><ul><li><?php bb_e( 'address_1' ); ?></li><li><?php bb_e( 'address_2' ); ?></li><li style="margin-top:8px"><a href="<?php echo esc_url( bb_ig_url() ); ?>" target="_blank" rel="noopener">Instagram · <?php echo esc_html( '@' . ltrim( bb_opt( 'instagram' ), '@' ) ); ?></a></li><li><a href="<?php echo esc_url( bb_opt( 'hellopeter_url' ) ); ?>" target="_blank" rel="noopener">Review us on Hellopeter</a></li></ul></div>
    </div>
    <div class="fbottom"><span>© <?php echo esc_html( gmdate( 'Y' ) ); ?> BB Cars Auto Body. All rights reserved.</span><span>www.bbcars.co.za</span></div>
  </div>
</footer>

<nav class="mbar" aria-label="Quick actions">
  <a href="<?php echo esc_attr( bb_tel( 'reception_phone' ) ); ?>"><svg><use href="#i-phone"/></svg>Call</a>
  <a href="<?php echo esc_attr( bb_mailto( 'reception_email' ) ); ?>"><svg><use href="#i-mail"/></svg>Email</a>
  <a class="q" href="<?php echo esc_url( bb_home_anchor( 'contact' ) ); ?>"><svg><use href="#i-quote"/></svg>Get a quote</a>
</nav>


<?php wp_footer(); ?>
</body>
</html>
