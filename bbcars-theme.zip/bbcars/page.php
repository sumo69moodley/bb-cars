<?php
/**
 * Page
 *
 * @package bbcars
 */
get_header();
?>
<section class="pad page-default"><div class="wrap">
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
  <article <?php post_class( 'entry' ); ?>>
    <h1 class="entry-title"><?php the_title(); ?></h1>
    <div class="entry-content"><?php the_content(); ?></div>
  </article>
<?php endwhile; else : ?>
  <h1>Page not found</h1><p><a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>">Back to home</a></p>
<?php endif; ?>
</div></section>
<?php get_footer();
