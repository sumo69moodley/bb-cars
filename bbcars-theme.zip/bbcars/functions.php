<?php
/**
 * BB Cars Auto Body theme functions.
 *
 * @package bbcars
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'BB_VER', '1.0.0' );
define( 'BB_URI', get_template_directory_uri() );

require get_template_directory() . '/inc/data.php';

/* ---------------------------------------------------------------- Setup */
add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array( 'height' => 120, 'width' => 200, 'flex-width' => true, 'flex-height' => true ) );
	register_nav_menus( array( 'primary' => __( 'Main menu', 'bbcars' ) ) );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'bb-fonts', 'https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@500;600;700&family=Barlow:wght@400;500;600;700&display=swap', array(), null );
	wp_enqueue_style( 'bb-style', get_stylesheet_uri(), array( 'bb-fonts' ), BB_VER );
	wp_enqueue_script( 'bb-main', BB_URI . '/assets/js/main.js', array(), BB_VER, true );
} );

add_filter( 'wp_resource_hints', function ( $urls, $rel ) {
	if ( 'preconnect' === $rel ) {
		$urls[] = 'https://fonts.googleapis.com';
		$urls[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' );
	}
	return $urls;
}, 10, 2 );

/* ---------------------------------------------------------------- Options (Customizer) */
function bb_defaults() {
	return array(
		'reception_phone' => '011 887 3120',
		'jakes_phone'     => '083 554 0175',
		'reception_email' => 'Reception@bbcars.co.za',
		'accounts_email'  => 'accounts@bbcars.co.za',
		'jakes_email'     => 'jakes@bbcars.co.za',
		'address_1'       => '18 5th Street, Wynberg',
		'address_2'       => 'Sandton, 2090',
		'instagram'       => 'bbcars.sa',
		'hellopeter_url'  => 'https://api.hellopeter.com/r/2BwsueGijtazmqPtoG4mdRQL6',
		'hellopeter_code' => '',
		'quote_to'        => 'Reception@bbcars.co.za',
		'slide_1'         => '',
		'slide_2'         => '',
		'slide_3'         => '',
	);
}

function bb_opt( $key ) {
	$d = bb_defaults();
	$v = get_theme_mod( 'bb_' . $key, isset( $d[ $key ] ) ? $d[ $key ] : '' );
	return ( '' === $v && isset( $d[ $key ] ) && 'hellopeter_code' !== $key && 0 !== strpos( $key, 'slide_' ) ) ? $d[ $key ] : $v;
}
function bb_e( $key ) { echo esc_html( bb_opt( $key ) ); }
function bb_tel( $key ) {
	$n = preg_replace( '/\D+/', '', bb_opt( $key ) );
	if ( 0 === strpos( $n, '0' ) ) { $n = '27' . substr( $n, 1 ); }
	return 'tel:+' . $n;
}
function bb_mailto( $key ) { return 'mailto:' . bb_opt( $key ); }
function bb_ig_url() { return 'https://www.instagram.com/' . rawurlencode( ltrim( bb_opt( 'instagram' ), '@' ) ) . '/'; }
function bb_slide_img( $n, $fallback ) {
	$custom = bb_opt( 'slide_' . $n );
	return $custom ? $custom : BB_URI . '/assets/img/' . $fallback;
}
function bb_approvals_url() {
	$id = (int) get_option( 'bb_approvals_page_id' );
	if ( $id && 'publish' === get_post_status( $id ) ) { return get_permalink( $id ); }
	return home_url( '/#manufacturers' );
}
function bb_home_anchor( $id ) { return is_front_page() ? '#' . $id : home_url( '/#' . $id ); }

add_action( 'customize_register', function ( $wp ) {
	$wp->add_section( 'bb_contact', array( 'title' => 'BB Cars – Contact details', 'priority' => 30 ) );
	$wp->add_section( 'bb_reviews', array( 'title' => 'BB Cars – Hellopeter reviews', 'priority' => 31 ) );
	$wp->add_section( 'bb_hero', array( 'title' => 'BB Cars – Hero slider images', 'priority' => 32 ) );
	$d = bb_defaults();
	$fields = array(
		'reception_phone' => array( 'Reception phone', 'bb_contact' ),
		'jakes_phone'     => array( 'Jakes phone', 'bb_contact' ),
		'reception_email' => array( 'Reception email', 'bb_contact' ),
		'accounts_email'  => array( 'Accounts email', 'bb_contact' ),
		'jakes_email'     => array( 'Jakes email', 'bb_contact' ),
		'address_1'       => array( 'Address line 1', 'bb_contact' ),
		'address_2'       => array( 'Address line 2', 'bb_contact' ),
		'instagram'       => array( 'Instagram handle (without @)', 'bb_contact' ),
		'quote_to'        => array( 'Send quote requests to (email)', 'bb_contact' ),
		'hellopeter_url'  => array( 'Hellopeter review link', 'bb_reviews' ),
	);
	foreach ( $fields as $k => $f ) {
		$wp->add_setting( 'bb_' . $k, array( 'default' => $d[ $k ], 'sanitize_callback' => ( false !== strpos( $k, 'email' ) || 'quote_to' === $k ) ? 'sanitize_email' : ( 'hellopeter_url' === $k ? 'esc_url_raw' : 'sanitize_text_field' ) ) );
		$wp->add_control( 'bb_' . $k, array( 'label' => $f[0], 'section' => $f[1], 'type' => 'text' ) );
	}
	$wp->add_setting( 'bb_hellopeter_code', array( 'default' => '', 'sanitize_callback' => 'bb_sanitize_embed' ) );
	$wp->add_control( 'bb_hellopeter_code', array(
		'label'       => 'Hellopeter live review widget code',
		'description' => 'Paste the embed code from Hellopeter Business (Widgets › Review feed). Leave empty to show the review button and QR code only.',
		'section'     => 'bb_reviews',
		'type'        => 'textarea',
	) );
	for ( $i = 1; $i <= 3; $i++ ) {
		$wp->add_setting( 'bb_slide_' . $i, array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
		$wp->add_control( new WP_Customize_Image_Control( $wp, 'bb_slide_' . $i, array( 'label' => 'Slide ' . $i . ' background', 'section' => 'bb_hero' ) ) );
	}
} );

/** Only administrators with unfiltered_html may save widget script code. */
function bb_sanitize_embed( $v ) {
	return current_user_can( 'unfiltered_html' ) ? $v : wp_kses_post( $v );
}

/* ---------------------------------------------------------------- Manufacturer Approvals page */
add_action( 'after_switch_theme', function () {
	$id = (int) get_option( 'bb_approvals_page_id' );
	if ( $id && get_post( $id ) ) { return; }
	$existing = get_page_by_path( 'manufacturer-approvals' );
	if ( $existing ) {
		$id = $existing->ID;
	} else {
		$id = wp_insert_post( array(
			'post_title'  => 'Manufacturer Approvals',
			'post_name'   => 'manufacturer-approvals',
			'post_status' => 'publish',
			'post_type'   => 'page',
		) );
	}
	if ( $id && ! is_wp_error( $id ) ) {
		update_post_meta( $id, '_wp_page_template', 'template-approvals.php' );
		update_option( 'bb_approvals_page_id', $id );
	}
} );

/* ---------------------------------------------------------------- Quote form */
add_action( 'admin_post_nopriv_bb_quote', 'bb_handle_quote' );
add_action( 'admin_post_bb_quote', 'bb_handle_quote' );
function bb_handle_quote() {
	$back = wp_get_referer() ? wp_get_referer() : home_url( '/' );
	$back = remove_query_arg( 'quote', strtok( $back, '#' ) );
	if ( ! isset( $_POST['bb_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['bb_nonce'] ) ), 'bb_quote' ) || ! empty( $_POST['website'] ) ) {
		wp_safe_redirect( add_query_arg( 'quote', 'error', $back ) . '#contact' );
		exit;
	}
	$f = array();
	foreach ( array( 'name', 'phone', 'email', 'vehicle', 'insurer', 'claim' ) as $k ) {
		$f[ $k ] = isset( $_POST[ $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) : '';
	}
	$msg = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';
	if ( '' === $f['name'] || '' === $f['phone'] ) {
		wp_safe_redirect( add_query_arg( 'quote', 'error', $back ) . '#contact' );
		exit;
	}
	$attachments = array();
	if ( ! empty( $_FILES['photos']['name'][0] ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$files = $_FILES['photos']; // phpcs:ignore
		$count = min( count( $files['name'] ), 6 );
		for ( $i = 0; $i < $count; $i++ ) {
			if ( UPLOAD_ERR_OK !== $files['error'][ $i ] || $files['size'][ $i ] > 8 * MB_IN_BYTES ) { continue; }
			$one = array( 'name' => $files['name'][ $i ], 'type' => $files['type'][ $i ], 'tmp_name' => $files['tmp_name'][ $i ], 'error' => 0, 'size' => $files['size'][ $i ] );
			$up  = wp_handle_upload( $one, array( 'test_form' => false, 'mimes' => array( 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'heic' => 'image/heic', 'webp' => 'image/webp' ) ) );
			if ( ! empty( $up['file'] ) ) { $attachments[] = $up['file']; }
		}
	}
	$body  = "New quote request from the BB Cars website\n\n";
	$body .= "Name: {$f['name']}\nPhone: {$f['phone']}\nEmail: {$f['email']}\nVehicle: {$f['vehicle']}\nInsurer: {$f['insurer']}\nClaim number: {$f['claim']}\n\nDamage description:\n{$msg}\n";
	$headers = array();
	if ( is_email( $f['email'] ) ) { $headers[] = 'Reply-To: ' . $f['name'] . ' <' . $f['email'] . '>'; }
	$sent = wp_mail( bb_opt( 'quote_to' ), 'Quote request: ' . $f['name'] . ( $f['vehicle'] ? ' – ' . $f['vehicle'] : '' ), $body, $headers, $attachments );
	foreach ( $attachments as $a ) { wp_delete_file( $a ); }
	wp_safe_redirect( add_query_arg( 'quote', $sent ? 'sent' : 'error', $back ) . '#contact' );
	exit;
}

/* ---------------------------------------------------------------- Menu fallback */
function bb_default_menu() {
	$items = array(
		array( bb_home_anchor( 'about' ), 'About' ),
		array( bb_home_anchor( 'customer-care' ), 'Customer Care' ),
		array( bb_home_anchor( 'insurers' ), 'Insurers' ),
		array( bb_home_anchor( 'services' ), 'Services' ),
		array( bb_approvals_url(), 'Approvals' ),
		array( bb_home_anchor( 'reviews' ), 'Reviews' ),
		array( bb_home_anchor( 'contact' ), 'Contact' ),
	);
	foreach ( $items as $i ) {
		echo '<a href="' . esc_url( $i[0] ) . '">' . esc_html( $i[1] ) . '</a>';
	}
}
function bb_menu() {
	if ( has_nav_menu( 'primary' ) ) {
		wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'items_wrap' => '%3$s', 'depth' => 1, 'walker' => new BB_Flat_Walker() ) );
	} else {
		bb_default_menu();
	}
}
class BB_Flat_Walker extends Walker_Nav_Menu {
	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		$output .= '<a href="' . esc_url( $item->url ) . '">' . esc_html( $item->title ) . '</a>';
	}
	public function end_el( &$output, $item, $depth = 0, $args = null ) {}
}

/* SVG icon sprite reference */
function bb_icon( $id ) { return '<svg aria-hidden="true"><use href="#i-' . esc_attr( $id ) . '"/></svg>'; }
