<?php
/**
 * Header
 *
 * @package bbcars
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<svg width="0" height="0" style="position:absolute" aria-hidden="true">
  <defs>
    <symbol id="i-phone" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/></symbol>
    <symbol id="i-mail" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/></symbol>
    <symbol id="i-pin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/></symbol>
    <symbol id="i-ig" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r=".8" fill="currentColor"/></symbol>
    <symbol id="i-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></symbol>
    <symbol id="i-left" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></symbol>
    <symbol id="i-right" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></symbol>
    <symbol id="i-quote" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h5"/></symbol>
    <symbol id="i-star" viewBox="0 0 24 24" fill="currentColor"><path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/></symbol>
    <symbol id="i-close" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></symbol>
    <symbol id="i-menu" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></symbol>
  </defs>
</svg>

<div class="topbar">
  <div class="wrap">
    <div class="items">
      <span><svg><use href="#i-pin"/></svg><?php echo esc_html( bb_opt( 'address_1' ) . ', ' . bb_opt( 'address_2' ) ); ?></span>
      <span><svg><use href="#i-mail"/></svg><a href="<?php echo esc_attr( bb_mailto( 'reception_email' ) ); ?>"><?php bb_e( 'reception_email' ); ?></a></span>
    </div>
    <div class="items">
      <span><svg><use href="#i-phone"/></svg>Reception <a href="<?php echo esc_attr( bb_tel( 'reception_phone' ) ); ?>"><?php bb_e( 'reception_phone' ); ?></a></span>
      <span><svg><use href="#i-phone"/></svg>Jakes <a href="<?php echo esc_attr( bb_tel( 'jakes_phone' ) ); ?>"><?php bb_e( 'jakes_phone' ); ?></a></span>
      <span><svg><use href="#i-ig"/></svg><a href="<?php echo esc_url( bb_ig_url() ); ?>" target="_blank" rel="noopener"><?php echo esc_html( '@' . ltrim( bb_opt( 'instagram' ), '@' ) ); ?></a></span>
    </div>
  </div>
</div>

<header class="header" id="top">
  <div class="wrap">
    <a class="brand" href="<?php echo esc_url( bb_home_anchor( 'top' ) ); ?>" aria-label="BB Cars Auto Body home"><?php if ( has_custom_logo() ) { $lid = get_theme_mod( 'custom_logo' ); echo wp_get_attachment_image( $lid, 'full', false, array( 'alt' => get_bloginfo( 'name' ) ) ); } else { ?><img src="<?php echo esc_url( BB_URI ); ?>/assets/img/logo-white.png" alt="<?php bloginfo( 'name' ); ?>" width="140" height="86"><?php } ?></a>
    <nav class="nav" aria-label="Main">
      <?php bb_menu(); ?>
    </nav>
    <div class="cta">
      <a class="btn ghost hide-sm" href="<?php echo esc_attr( bb_tel( 'reception_phone' ) ); ?>"><svg><use href="#i-phone"/></svg><?php bb_e( 'reception_phone' ); ?></a>
      <a class="btn" href="<?php echo esc_url( bb_home_anchor( 'contact' ) ); ?>">Get a quote</a>
      <button class="menu-btn" id="menuBtn" aria-label="Open menu" aria-expanded="false" aria-controls="drawer"><svg><use href="#i-menu"/></svg></button>
    </div>
  </div>
</header>

<div class="drawer" id="drawer" aria-hidden="true">
  <div class="top">
    <img src="<?php echo esc_url( BB_URI ); ?>/assets/img/logo-white.png" alt="BB Cars Auto Body" style="height:44px;width:auto">
    <button class="menu-btn" id="menuClose" aria-label="Close menu" style="display:inline-grid"><svg><use href="#i-close"/></svg></button>
  </div>
  <nav aria-label="Mobile">
    <?php bb_menu(); ?>
  </nav>
  <div class="contact">
    <span>Reception · <a href="<?php echo esc_attr( bb_tel( 'reception_phone' ) ); ?>"><?php bb_e( 'reception_phone' ); ?></a></span>
    <span>Jakes · <a href="<?php echo esc_attr( bb_tel( 'jakes_phone' ) ); ?>"><?php bb_e( 'jakes_phone' ); ?></a></span>
    <span><a href="<?php echo esc_attr( bb_mailto( 'reception_email' ) ); ?>"><?php bb_e( 'reception_email' ); ?></a></span>
    <a class="btn" href="<?php echo esc_url( bb_home_anchor( 'contact' ) ); ?>" style="margin-top:14px;justify-content:center">Get a quote</a>
  </div>
</div>

<main id="content">
