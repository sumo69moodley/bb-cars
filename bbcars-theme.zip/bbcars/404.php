<?php
/**
 * 404
 *
 * @package bbcars
 */
get_header();
?>
<section class="pad page-default"><div class="wrap"><span class="eyebrow">404</span><h1 class="entry-title">This page could not be found</h1><p class="lede" style="margin:16px 0 24px">The page may have moved. Head back to the homepage or call reception on <?php bb_e( 'reception_phone' ); ?>.</p><a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>">Back to home</a></div></section>
<?php get_footer();
